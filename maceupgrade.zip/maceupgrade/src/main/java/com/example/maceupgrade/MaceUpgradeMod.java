package com.example.maceupgrade;

import java.util.List;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

/**
 * Kill a player while holding a mace and the mace upgrades.
 *
 * 5 upgrade tiers. The kills needed for each upgrade multiply by themselves:
 *   upgrade 1 = 1x1 = 1 kill
 *   upgrade 2 = 2x2 = 4 kills
 *   upgrade 3 = 3x3 = 9 kills
 *   upgrade 4 = 4x4 = 16 kills
 *   upgrade 5 = 5x5 = 25 kills
 * Kills count toward the next upgrade only, and reset after each upgrade.
 */
public class MaceUpgradeMod implements ModInitializer {
	public static final int MAX_TIER = 5;
	private static final double BONUS_DAMAGE_PER_TIER = 3.0;

	private static final String[] NAMES = {
		"Mace", "Copper Mace", "Iron Mace", "Golden Mace", "Diamond Mace", "Netherite Mace"
	};
	private static final Formatting[] COLORS = {
		Formatting.WHITE, Formatting.GOLD, Formatting.GRAY, Formatting.YELLOW, Formatting.AQUA, Formatting.DARK_PURPLE
	};

	@Override
	public void onInitialize() {
		ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
			if (!(entity instanceof ServerPlayerEntity)) {
				return;
			}
			if (!(source.getAttacker() instanceof ServerPlayerEntity killer) || killer == entity) {
				return;
			}
			ItemStack mace = killer.getMainHandStack();
			if (!mace.isOf(Items.MACE)) {
				return;
			}
			handleKill(killer, mace);
		});
	}

	private static void handleKill(ServerPlayerEntity killer, ItemStack mace) {
		NbtComponent existing = mace.get(DataComponentTypes.CUSTOM_DATA);
		NbtCompound data = existing == null ? new NbtCompound() : existing.copyNbt();

		int tier = data.getInt("mace_tier", 0);
		int kills = data.getInt("mace_kills", 0);

		if (tier >= MAX_TIER) {
			killer.sendMessage(Text.literal("Your mace is already at max tier!").formatted(Formatting.LIGHT_PURPLE), true);
			return;
		}

		kills++;
		int needed = killsNeeded(tier + 1);

		if (kills >= needed) {
			tier++;
			kills = 0;
			killer.playSound(SoundEvents.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
			killer.sendMessage(Text.literal("Your mace upgraded to " + NAMES[tier] + "! (Tier " + tier + "/" + MAX_TIER + ")")
				.formatted(COLORS[tier], Formatting.BOLD), true);
		} else {
			killer.sendMessage(Text.literal("Mace progress: " + kills + "/" + needed + " kills")
				.formatted(Formatting.GREEN), true);
		}

		data.putInt("mace_tier", tier);
		data.putInt("mace_kills", kills);
		mace.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(data));

		applyTier(mace, tier, kills);
	}

	/** Kills needed to reach the given upgrade: the number multiplied by itself. */
	public static int killsNeeded(int upgradeNumber) {
		return upgradeNumber * upgradeNumber;
	}

	private static void applyTier(ItemStack mace, int tier, int kills) {
		// Vanilla mace: +5 attack damage (6 total with base 1), -3.4 attack speed.
		AttributeModifiersComponent attributes = AttributeModifiersComponent.builder()
			.add(EntityAttributes.ATTACK_DAMAGE,
				new EntityAttributeModifier(Identifier.ofVanilla("base_attack_damage"),
					5.0 + tier * BONUS_DAMAGE_PER_TIER, EntityAttributeModifier.Operation.ADD_VALUE),
				AttributeModifierSlot.MAINHAND)
			.add(EntityAttributes.ATTACK_SPEED,
				new EntityAttributeModifier(Identifier.ofVanilla("base_attack_speed"),
					-3.4, EntityAttributeModifier.Operation.ADD_VALUE),
				AttributeModifierSlot.MAINHAND)
			.build();
		mace.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, attributes);

		if (tier > 0) {
			mace.set(DataComponentTypes.CUSTOM_NAME,
				Text.literal(NAMES[tier]).styled(s -> s.withItalic(false)).formatted(COLORS[tier]));
			mace.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
		}

		Text tierLine = Text.literal("Tier " + tier + "/" + MAX_TIER).styled(s -> s.withItalic(false)).formatted(COLORS[tier]);
		Text progressLine;
		if (tier >= MAX_TIER) {
			progressLine = Text.literal("MAX TIER").styled(s -> s.withItalic(false)).formatted(Formatting.LIGHT_PURPLE);
		} else {
			progressLine = Text.literal("Next upgrade: " + kills + "/" + killsNeeded(tier + 1) + " player kills")
				.styled(s -> s.withItalic(false)).formatted(Formatting.GRAY);
		}
		mace.set(DataComponentTypes.LORE, new LoreComponent(List.of(tierLine, progressLine)));
	}
}
